const Field = {
    size: 9,

}

export default Field;