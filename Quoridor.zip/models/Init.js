const conf = {
    INIT_WALLS: 10,
    // game types
    PLAYER_COMPUTER: 1,
    PLAYER_PLAYER: 2,
    
}

export default conf;